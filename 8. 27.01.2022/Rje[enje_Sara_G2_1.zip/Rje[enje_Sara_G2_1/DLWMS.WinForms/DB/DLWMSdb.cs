﻿namespace DLWMS.WinForms.DB
{
    public class DLWMSdb
    {
        public static KonekcijaNaBazu Baza = new KonekcijaNaBazu();
    }
}